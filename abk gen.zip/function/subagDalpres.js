function dataDalpres(dateParam) {
const data = [
    [dateParam,"giat", "APEL DI MAKO POLRES", 3, 1, "-"],
    [dateParam,"dok", "MEMBUAT SPRINT TUGAS", 1, 3, "-"],
    [dateParam,"dok", "MENGUPDATE SIPK ONLINE", 1, 2, "-"],
    [dateParam,"dok", "ADMINISTRASI MENGENAI UKGB", 1, 2, "-"],
    [dateParam,"dok", "MENGUPDATE DATA PADA APLIKASI SIPP", 1, 2, "-"],
    [dateParam,"dok", "PELAKSANAAN ADMINISTRASI ASSESMEN", 1, 4, "-"],
    [dateParam,"dok", "melaksanakan administrasi pegawai polri dalam pembinaan karir meliputi usulan kenaikan pangkat & mutasi serta pengangkatan & pemberhentian dalam jabatan", 1, 3, "-"],
    ["dok", "pembinaan karir personel meliputi mutasi , pengangkatan dan pemberentian dalam jabatan", 1, 3, "-"]
  ];
    return data;
}

module.exports = { dataDalpres };